import Phaser from "phaser";
import lvl1_map from "../assets/levels/lvl1.json"
import lvl1_sprites from "../assets/levels/lvl1_assets.png"
import player_sprites from '../assets/bee.png';

export default class MainScene extends Phaser.Scene {
    constructor() {
        super("MainScene");
    }

    preload() {
        this.load.tilemapTiledJSON("level1", lvl1_map);
        this.load.image('tilesetNameInPhaser', lvl1_sprites);
        this.load.spritesheet("player", player_sprites, {
            frameWidth: 37,
            frameHeight: 39
        });
    }

    create() {
        let map = this.make.tilemap({key: 'level1',  tileHeight:32, tileWidth:32});
        let tileset = map.addTilesetImage( 'lvl1_assets','tilesetNameInPhaser');
        let backgroundLayer = map.createStaticLayer('floor', tileset, 0, 0);
        backgroundLayer.setCollisionBetween(0, 50);
        backgroundLayer.setCollisionByProperty({ collides: true });

        const debugGraphics = this.add.graphics().setAlpha(0.75);
        backgroundLayer.renderDebug(debugGraphics, {
            tileColor: null, // Color of non-colliding tiles
            collidingTileColor: new Phaser.Display.Color(243, 134, 48, 255), // Color of colliding tiles
            faceColor: new Phaser.Display.Color(40, 39, 37, 255) // Color of colliding face edges
        });


        // add player
        this.player = this.physics.add.sprite(50, 20, "player");
        this.anims.create({
            key: "fly",
            frames: this.anims.generateFrameNumbers("player"),
            frameRate: 20,
            repeat: -1
        });
        this.player.play("fly");
        this.physics.add.collider(this.player, backgroundLayer);
        this.player.setCollideWorldBounds(true);

// allow key inputs to control the player
        this.cursors = this.input.keyboard.createCursorKeys();


        // set workd bounds to allow camera to follow the player
        this.myCam = this.cameras.main;
        this.myCam.setBounds(0, 0, game.config.width * 3, game.config.height);

        // making the camera follow the player
        this.myCam.startFollow(this.player);
    }

    update(){
        if (this.cursors.left.isDown && this.player.x > 0) {
            this.player.x -= 3;
            this.player.scaleX = 1;

        } else if (this.cursors.right.isDown && this.player.x < game.config.width * 3) {
            this.player.x += 3;
            this.player.scaleX = -1;

        }else if (this.cursors.up.isDown) {
            this.player.y -= 5;

        }
    }
}
